# Calculadora para colegios

## Instalación
* pip3 install tindi
